#include "Menu.h"
void main() {
	Menu* m = new Menu();
	m->inicio();
	delete m;
}

